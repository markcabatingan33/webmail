/* MyWebMail – frontend logic shared by every page.
   Each page sets <body data-page="..."> and the code at the bottom starts the right screen. */

const API = '/api';
const TOKEN_KEY = 'mywebmail_token';
const USER_KEY = 'mywebmail_user';
const FLASH_KEY = 'mywebmail_flash';

/* ------------------------------------------------------------------ */
/* Small helpers                                                       */
/* ------------------------------------------------------------------ */

const $ = (selector, root = document) => root.querySelector(selector);

// Every piece of text that came from a user goes through esc() before it is put into HTML.
const esc = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));

const ICONS = {
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  inbox: '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
  send: '<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h5"/>',
  trash: '<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/>',
  reply: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 6 6v3"/>',
  restore: '<path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-15-6.7L3 13"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
};

function icon(name, size = 18) {
  return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;
}

function formatListDate(value) {
  const date = new Date(value);
  const now = new Date();
  if (date.toDateString() === now.toDateString()) {
    return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) return 'Yesterday';
  const options = { month: 'short', day: 'numeric' };
  if (date.getFullYear() !== now.getFullYear()) options.year = 'numeric';
  return date.toLocaleDateString([], options);
}

function formatFullDate(value) {
  return new Date(value).toLocaleString([], {
    weekday: 'short', month: 'short', day: 'numeric', year: 'numeric',
    hour: 'numeric', minute: '2-digit',
  });
}

/* ------------------------------------------------------------------ */
/* Session, API calls, toast                                           */
/* ------------------------------------------------------------------ */

const session = {
  get token() { return localStorage.getItem(TOKEN_KEY); },
  get user() {
    try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch (e) { return null; }
  },
  save(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },
};

function logout() {
  session.clear();
  location.href = 'login.html';
}

// Pages that need a logged-in user call this first. Returns false (and redirects) if not logged in.
function requireAuth() {
  if (session.token && session.user) return true;
  session.clear();
  location.href = 'login.html';
  return false;
}

async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (session.token) headers.Authorization = `Bearer ${session.token}`;

  let response;
  try {
    response = await fetch(API + path, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (err) {
    throw new Error('Cannot reach the server. Check that it is running.');
  }

  let data = null;
  try { data = await response.json(); } catch (err) { /* empty or non-JSON body */ }

  if (response.status === 401 && session.token) {
    session.clear();
    location.href = 'login.html';
    throw new Error('Your session has expired. Please log in again.');
  }
  if (!response.ok) throw new Error((data && data.message) || 'Something went wrong. Please try again.');
  return data;
}

let toastTimer;
function toast(message, type = '') {
  let el = $('#toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    el.className = 'toast';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.className = `toast ${type}`;
  // Force a reflow so the transition runs even when a toast is already showing.
  void el.offsetWidth;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

// A message that should appear on the *next* page (for example after sending).
function flash(message) { sessionStorage.setItem(FLASH_KEY, message); }
function showFlash() {
  const message = sessionStorage.getItem(FLASH_KEY);
  if (message) {
    sessionStorage.removeItem(FLASH_KEY);
    toast(message);
  }
}

function showFormError(message) {
  const el = $('#formError');
  el.textContent = message;
  el.classList.remove('hidden');
}
function hideFormError() { $('#formError').classList.add('hidden'); }

/* ------------------------------------------------------------------ */
/* Sidebar                                                             */
/* ------------------------------------------------------------------ */

const NAV = [
  { key: 'inbox', label: 'Inbox', href: 'inbox.html', icon: 'inbox' },
  { key: 'sent', label: 'Sent', href: 'sent.html', icon: 'send' },
  { key: 'drafts', label: 'Drafts', href: 'drafts.html', icon: 'file' },
  { key: 'trash', label: 'Trash', href: 'trash.html', icon: 'trash' },
];

function renderSidebar(active) {
  const user = session.user;
  $('#sidebar').innerHTML = `
    <a class="brand" href="inbox.html">${icon('mail', 22)}<span>MyWebMail</span></a>
    <nav class="nav" aria-label="Mailboxes">
      ${NAV.map((item) => `
        <a href="${item.href}" class="nav-link${item.key === active ? ' active' : ''}"${item.key === active ? ' aria-current="page"' : ''}>
          ${icon(item.icon)}<span>${item.label}</span><span class="badge hidden" data-badge="${item.key}"></span>
        </a>`).join('')}
    </nav>
    <div class="sidebar-foot">
      <a class="btn btn-primary btn-block" href="compose.html">${icon('plus', 16)}<span>Compose</span></a>
      <div class="account">
        <span class="avatar" aria-hidden="true">${esc((user.name || user.email).trim().charAt(0).toUpperCase())}</span>
        <span class="account-text"><strong>${esc(user.name)}</strong><small>${esc(user.email)}</small></span>
        <button type="button" class="icon-btn" id="logoutBtn" title="Log out" aria-label="Log out">${icon('logout')}</button>
      </div>
    </div>`;
  $('#logoutBtn').addEventListener('click', logout);
  refreshCounts();
}

function setBadge(key, count) {
  const el = $(`[data-badge="${key}"]`);
  if (!el) return;
  el.textContent = count;
  el.classList.toggle('hidden', !count);
}

async function refreshCounts() {
  try {
    const counts = await api('/mail/counts');
    setBadge('inbox', counts.unread);
    setBadge('drafts', counts.drafts);
    document.dispatchEvent(new CustomEvent('counts', { detail: counts }));
    return counts;
  } catch (err) {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* Message reader (opens over the list)                                */
/* ------------------------------------------------------------------ */

function openReader(message, { folder, onAction }) {
  const me = session.user;
  const previousFocus = document.activeElement;
  const isReceiver = message.receiver_id === me.id;
  const from = `${message.sender_name} <${message.sender_email}>`;
  const to = message.receiver_email
    ? `${message.receiver_name} <${message.receiver_email}>`
    : (message.draft_to || 'No recipient');

  const actions = [];
  if (folder === 'trash') {
    actions.push(`<button type="button" class="btn btn-ghost" data-action="restore">${icon('restore', 16)}<span>Restore</span></button>`);
    actions.push(`<button type="button" class="btn btn-danger" data-action="forever">${icon('trash', 16)}<span>Delete forever</span></button>`);
  } else {
    if (isReceiver) actions.push(`<a class="btn btn-primary" data-reply href="#">${icon('reply', 16)}<span>Reply</span></a>`);
    actions.push(`<button type="button" class="btn btn-ghost" data-action="delete">${icon('trash', 16)}<span>Delete</span></button>`);
  }

  const overlay = document.createElement('div');
  overlay.className = 'overlay';
  overlay.innerHTML = `
    <article class="reader" role="dialog" aria-modal="true" aria-labelledby="readerSubject">
      <header class="reader-head">
        <h2 id="readerSubject"></h2>
        <button type="button" class="icon-btn" data-close aria-label="Close">${icon('x')}</button>
      </header>
      <dl class="reader-meta">
        <div><dt>From</dt><dd data-from></dd></div>
        <div><dt>To</dt><dd data-to></dd></div>
        <div><dt>Date</dt><dd data-date></dd></div>
      </dl>
      <div class="reader-body" data-body></div>
      <footer class="reader-actions">${actions.join('')}</footer>
    </article>`;

  // Message text is inserted as plain text, never as HTML.
  $('#readerSubject', overlay).textContent = message.subject || '(no subject)';
  $('[data-from]', overlay).textContent = from;
  $('[data-to]', overlay).textContent = to;
  $('[data-date]', overlay).textContent = formatFullDate(message.sent_at);
  $('[data-body]', overlay).textContent = message.body;

  const replyLink = $('[data-reply]', overlay);
  if (replyLink) {
    const subject = /^re:/i.test(message.subject) ? message.subject : `Re: ${message.subject}`;
    replyLink.href = `compose.html?to=${encodeURIComponent(message.sender_email)}&subject=${encodeURIComponent(subject)}`;
  }

  function close() {
    document.removeEventListener('keydown', onKey);
    overlay.remove();
    if (previousFocus && previousFocus.focus) previousFocus.focus();
  }

  function onKey(event) {
    if (event.key === 'Escape') return close();
    if (event.key !== 'Tab') return;
    // Keep keyboard focus inside the dialog.
    const focusable = overlay.querySelectorAll('button, a[href]');
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }

  overlay.addEventListener('click', (event) => {
    if (event.target === overlay || event.target.closest('[data-close]')) return close();
    const button = event.target.closest('[data-action]');
    if (button) {
      close();
      onAction(button.dataset.action, message.id);
    }
  });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(overlay);
  $('[data-close]', overlay).focus();
}

/* ------------------------------------------------------------------ */
/* Mailbox pages: inbox, sent, drafts, trash                           */
/* ------------------------------------------------------------------ */

const FOLDERS = {
  inbox: { title: 'Inbox', empty: 'Your inbox is empty', hint: 'New messages will show up here.' },
  sent: { title: 'Sent', empty: 'Nothing sent yet', hint: 'Messages you send will show up here.' },
  drafts: { title: 'Drafts', empty: 'No drafts', hint: 'Messages you save without sending will show up here.' },
  trash: { title: 'Trash', empty: 'Trash is empty', hint: 'Deleted messages stay here until you delete them forever.' },
};

function initFolder(folder) {
  if (!requireAuth()) return;
  renderSidebar(folder);

  const meta = FOLDERS[folder];
  const me = session.user;
  const listEl = $('#mailList');
  const state = { items: [], selected: new Set(), query: '', unread: 0, loaded: false };

  // Toolbar: select all, refresh, and the actions that make sense for this folder.
  $('#toolbar').innerHTML = `
    <label class="check" title="Select all"><input type="checkbox" id="selectAll" aria-label="Select all messages"></label>
    <button type="button" class="btn btn-ghost btn-sm" id="refreshBtn">${icon('refresh', 16)}<span>Refresh</span></button>
    ${folder === 'trash'
      ? `<button type="button" class="btn btn-ghost btn-sm" id="restoreBtn" disabled>${icon('restore', 16)}<span>Restore</span></button>
         <button type="button" class="btn btn-danger btn-sm" id="foreverBtn" disabled>${icon('trash', 16)}<span>Delete forever</span></button>`
      : `<button type="button" class="btn btn-ghost btn-sm" id="deleteBtn" disabled>${icon('trash', 16)}<span>Delete</span></button>`}`;

  function personFor(m) {
    if (folder === 'drafts') return m.draft_to ? `To: ${m.draft_to}` : 'No recipient';
    if (folder === 'sent') return `To: ${m.receiver_name || m.receiver_email || ''}`;
    if (folder === 'trash' && m.sender_id === me.id) {
      return m.is_draft ? 'Draft' : `To: ${m.receiver_name || m.receiver_email || ''}`;
    }
    return m.sender_name;
  }

  function rowHtml(m) {
    const unread = folder === 'inbox' && !m.is_read;
    const selected = state.selected.has(m.id);
    const preview = String(m.preview || '').replace(/\s+/g, ' ').trim();
    return `
      <div class="mail-row${unread ? ' unread' : ''}${selected ? ' selected' : ''}" data-id="${m.id}" role="button" tabindex="0">
        <label class="check"><input type="checkbox" data-select="${m.id}" aria-label="Select message"${selected ? ' checked' : ''}></label>
        <span class="who">${esc(personFor(m))}</span>
        <span class="what"><span class="subject">${esc(m.subject || '(no subject)')}</span>${preview ? `<span class="preview">${esc(preview)}</span>` : ''}</span>
        <time class="when" datetime="${esc(m.sent_at)}">${esc(formatListDate(m.sent_at))}</time>
      </div>`;
  }

  function updateTitle() {
    const count = folder === 'inbox' && state.unread > 0 ? ` (${state.unread})` : '';
    $('#folderTitle').textContent = meta.title + count;
  }

  function updateToolbar() {
    const some = state.selected.size > 0;
    ['deleteBtn', 'restoreBtn', 'foreverBtn'].forEach((id) => {
      const button = $('#' + id);
      if (button) button.disabled = !some;
    });
    const all = $('#selectAll');
    all.checked = state.items.length > 0 && state.selected.size === state.items.length;
    all.indeterminate = some && state.selected.size < state.items.length;
    all.disabled = state.items.length === 0;
  }

  function render() {
    updateTitle();
    if (!state.loaded) {
      listEl.innerHTML = '<div class="empty">Loading…</div>';
    } else if (!state.items.length) {
      listEl.innerHTML = state.query
        ? `<div class="empty"><strong>No results</strong>Nothing in ${esc(meta.title)} matches "${esc(state.query)}".</div>`
        : `<div class="empty"><strong>${meta.empty}</strong>${meta.hint}</div>`;
    } else {
      listEl.innerHTML = state.items.map(rowHtml).join('');
    }
    updateToolbar();
  }

  async function load() {
    try {
      state.items = await api(`/mail/folder/${folder}?q=${encodeURIComponent(state.query)}`);
      state.selected = new Set([...state.selected].filter((id) => state.items.some((m) => m.id === id)));
      state.loaded = true;
      render();
    } catch (err) {
      listEl.innerHTML = `<div class="empty"><strong>Could not load messages</strong>${esc(err.message)}</div>`;
    }
  }

  const ACTIONS = {
    delete: { done: 'Moved to Trash.', call: (id) => api(`/mail/${id}`, { method: 'DELETE' }) },
    restore: { done: 'Restored.', call: (id) => api(`/mail/${id}/restore`, { method: 'POST' }) },
    forever: { done: 'Deleted forever.', call: (id) => api(`/mail/${id}?permanent=true`, { method: 'DELETE' }) },
  };

  async function runAction(action, ids) {
    if (!ids.length) return;
    if (action === 'forever') {
      const what = ids.length === 1 ? 'this message' : `these ${ids.length} messages`;
      if (!window.confirm(`Delete ${what} forever? This cannot be undone.`)) return;
    }
    try {
      await Promise.all(ids.map((id) => ACTIONS[action].call(id)));
      state.items = state.items.filter((m) => !ids.includes(m.id));
      ids.forEach((id) => state.selected.delete(id));
      render();
      refreshCounts();
      toast(ACTIONS[action].done);
    } catch (err) {
      toast(err.message, 'error');
      load();
    }
  }

  async function openMessage(id) {
    if (folder === 'drafts') {
      location.href = `compose.html?draft=${id}`;
      return;
    }
    try {
      const message = await api(`/mail/${id}`);
      const item = state.items.find((m) => m.id === id);
      if (item && !item.is_read) { item.is_read = 1; render(); refreshCounts(); }
      openReader(message, { folder, onAction: (action, messageId) => runAction(action, [messageId]) });
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  // ----- events
  listEl.addEventListener('change', (event) => {
    const box = event.target.closest('[data-select]');
    if (!box) return;
    const id = Number(box.dataset.select);
    if (box.checked) state.selected.add(id); else state.selected.delete(id);
    box.closest('.mail-row').classList.toggle('selected', box.checked);
    updateToolbar();
  });

  listEl.addEventListener('click', (event) => {
    if (event.target.closest('.check')) return;
    const row = event.target.closest('.mail-row');
    if (row) openMessage(Number(row.dataset.id));
  });

  listEl.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && event.target.classList.contains('mail-row')) {
      openMessage(Number(event.target.dataset.id));
    }
  });

  $('#selectAll').addEventListener('change', (event) => {
    state.selected = event.target.checked ? new Set(state.items.map((m) => m.id)) : new Set();
    render();
  });

  $('#refreshBtn').addEventListener('click', () => { load(); refreshCounts(); });
  const wire = (id, action) => {
    const button = $('#' + id);
    if (button) button.addEventListener('click', () => runAction(action, [...state.selected]));
  };
  wire('deleteBtn', 'delete');
  wire('restoreBtn', 'restore');
  wire('foreverBtn', 'forever');

  let searchTimer;
  const searchInput = $('#searchInput');
  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.query = searchInput.value.trim(); load(); }, 250);
  });
  $('#searchForm').addEventListener('submit', (event) => {
    event.preventDefault();
    clearTimeout(searchTimer);
    state.query = searchInput.value.trim();
    load();
  });

  document.addEventListener('counts', (event) => { state.unread = event.detail.unread; updateTitle(); });

  render();
  load();
}

/* ------------------------------------------------------------------ */
/* Compose page                                                        */
/* ------------------------------------------------------------------ */

async function initCompose() {
  if (!requireAuth()) return;
  renderSidebar('compose');

  const form = $('#composeForm');
  const fields = form.elements;
  const params = new URLSearchParams(location.search);
  let draftId = null;

  // Opened from Drafts (?draft=5) or from Reply (?to=...&subject=...)
  const draftParam = Number(params.get('draft'));
  if (draftParam) {
    try {
      const draft = await api(`/mail/${draftParam}`);
      if (draft.is_draft && draft.sender_id === session.user.id) {
        draftId = draft.id;
        fields.to.value = draft.draft_to || '';
        fields.subject.value = draft.subject || '';
        fields.body.value = draft.body || '';
      } else {
        toast('That draft could not be found.', 'error');
      }
    } catch (err) {
      toast(err.message, 'error');
    }
  } else {
    fields.to.value = params.get('to') || '';
    fields.subject.value = params.get('subject') || '';
  }
  (fields.to.value ? fields.body : fields.to).focus();

  const values = () => ({
    to: fields.to.value.trim(),
    subject: fields.subject.value.trim(),
    body: fields.body.value,
    draftId,
  });
  const setBusy = (busy) => {
    $('#sendBtn').disabled = busy;
    $('#saveDraftBtn').disabled = busy;
  };

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    hideFormError();
    setBusy(true);
    try {
      await api('/mail/send', { method: 'POST', body: values() });
      flash('Message sent.');
      location.href = 'sent.html';
    } catch (err) {
      showFormError(err.message);
      setBusy(false);
    }
  });

  $('#saveDraftBtn').addEventListener('click', async () => {
    hideFormError();
    setBusy(true);
    try {
      const result = await api('/mail/draft', { method: 'POST', body: values() });
      draftId = result.id;
      history.replaceState(null, '', `compose.html?draft=${draftId}`);
      toast('Draft saved.');
      refreshCounts();
    } catch (err) {
      showFormError(err.message);
    }
    setBusy(false);
  });
}

/* ------------------------------------------------------------------ */
/* Home, login, register                                               */
/* ------------------------------------------------------------------ */

function initHome() {
  if (session.token && session.user) $('#getStarted').href = 'inbox.html';
}

function initAuthForm(kind) {
  if (session.token && session.user) {
    location.replace('inbox.html');
    return;
  }
  const form = $(kind === 'login' ? '#loginForm' : '#registerForm');
  const button = $('#submitBtn');
  const label = button.textContent;

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    hideFormError();
    const data = Object.fromEntries(new FormData(form));

    if (kind === 'register' && data.password !== data.confirm) {
      showFormError('The passwords do not match.');
      return;
    }

    button.disabled = true;
    button.textContent = kind === 'login' ? 'Logging in…' : 'Creating account…';
    try {
      const result = await api(`/auth/${kind}`, {
        method: 'POST',
        body: kind === 'login'
          ? { email: data.email, password: data.password }
          : { name: data.name, email: data.email, password: data.password },
      });
      session.save(result.token, result.user);
      location.href = 'inbox.html';
    } catch (err) {
      showFormError(err.message);
      button.disabled = false;
      button.textContent = label;
    }
  });
}

/* ------------------------------------------------------------------ */
/* Start the right screen                                              */
/* ------------------------------------------------------------------ */

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-icon]').forEach((el) => {
    el.innerHTML = icon(el.dataset.icon, Number(el.dataset.size) || 18);
  });
  showFlash();

  const page = document.body.dataset.page;
  if (FOLDERS[page]) initFolder(page);
  else if (page === 'compose') initCompose();
  else if (page === 'login') initAuthForm('login');
  else if (page === 'register') initAuthForm('register');
  else if (page === 'home') initHome();
});

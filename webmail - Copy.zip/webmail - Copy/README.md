# MyWebMail

A simple web mail app: register, log in, send messages to other users, and manage
Inbox, Sent, Drafts and Trash.

- **Backend:** Node.js + Express (REST API, JWT login, bcrypt passwords)
- **Database:** MySQL (or MariaDB)
- **Frontend:** plain HTML + CSS + JavaScript (served by Express, no build step)

## Run it

You need **Node.js 18+** and a running **MySQL** server.

```bash
npm install
cp .env.example .env        # then edit .env: DB_USER, DB_PASSWORD, JWT_SECRET
npm run init-db             # creates the database and tables
npm run seed                # optional: demo account + sample emails
npm start
```

Open **http://localhost:3000**.

Demo login (after `npm run seed`): `demo@mywebmail.com` / `password123`
(other seeded accounts use the same password: john@, maria@, alex@, support@, admin@ mywebmail.com).

Use `npm run dev` to restart the server automatically when you edit backend files.

> Open the site through `http://localhost:3000`, not by double-clicking the HTML files —
> the pages talk to the API on the same address.

## Folder structure

```
webmail/
├── package.json
├── .env.example
├── backend/
│   ├── server.js                 Express app: static files + API routes
│   ├── routes/
│   │   ├── auth.js               /api/auth   (register, login, me)
│   │   ├── mail.js               /api/mail   (folders, read, send, draft, delete, restore)
│   │   └── user.js               /api/user   (profile)
│   ├── controllers/
│   │   ├── authController.js
│   │   └── mailController.js
│   ├── middleware/auth.js        checks the login token
│   └── database/
│       ├── db.js                 MySQL connection pool
│       ├── schema.sql            tables: users, messages
│       ├── init.js               npm run init-db
│       ├── seed.js               npm run seed
│       └── models/
│           ├── User.js
│           └── Message.js
└── frontend/
    ├── index.html                welcome page
    ├── login.html   register.html
    ├── inbox.html   sent.html   drafts.html   trash.html
    ├── compose.html
    ├── style.css
    └── script.js                 all page logic
```

## API

All `/api/mail` and `/api/user` routes need the header `Authorization: Bearer <token>`.

| Method | Path | What it does |
|---|---|---|
| POST | `/api/auth/register` | `{name, email, password}` → `{token, user}` |
| POST | `/api/auth/login` | `{email, password}` → `{token, user}` |
| GET | `/api/auth/me` | current user |
| GET | `/api/mail/folder/:folder?q=` | `inbox`, `sent`, `drafts` or `trash`; `q` searches |
| GET | `/api/mail/counts` | `{unread, drafts}` |
| GET | `/api/mail/:id` | one message (marks it read for the receiver) |
| POST | `/api/mail/send` | `{to, subject, body, draftId?}` |
| POST | `/api/mail/draft` | `{to, subject, body, draftId?}` saves or updates a draft |
| DELETE | `/api/mail/:id` | move to Trash |
| POST | `/api/mail/:id/restore` | restore from Trash |
| DELETE | `/api/mail/:id?permanent=true` | delete forever (Trash only) |

## Good to know

- Mail is delivered **between MyWebMail accounts only**. Sending to a Gmail or Yahoo address
  would need an SMTP service (for example Nodemailer) added to `mailController.send`.
- File attachments are not included yet.
- Before putting this on the internet: set a long random `JWT_SECRET`, serve it over HTTPS,
  and add rate limiting on the login route.

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const express = require('express');
const cors = require('cors');
const db = require('./database/db');

const authRoutes = require('./routes/auth');
const mailRoutes = require('./routes/mail');
const userRoutes = require('./routes/user');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(cors());
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

app.use('/api/auth', authRoutes);
app.use('/api/mail', mailRoutes);
app.use('/api/user', userRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

// Unknown API routes get JSON instead of an HTML error page.
app.use('/api', (req, res) => res.status(404).json({ message: 'Not found.' }));

// Bad JSON bodies and any other uncaught errors.
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Invalid request.' });
  }
  console.error(err);
  res.status(500).json({ message: 'Server error. Please try again.' });
});

db.query('SELECT 1')
  .then(() => {
    if (!process.env.JWT_SECRET) {
      console.warn('Warning: JWT_SECRET is not set. Set it in .env before using this for real.');
    }
    app.listen(PORT, () => {
      console.log(`MyWebMail is running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Cannot connect to the database:', err.message);
    console.error('Did you run "npm run init-db"? Check the DB_* values in your .env file.');
    process.exit(1);
  });

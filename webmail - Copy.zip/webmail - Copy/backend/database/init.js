// Creates the database (if needed) and the tables.  Usage: npm run init-db
const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });
const mysql = require('mysql2/promise');

(async () => {
  const dbName = process.env.DB_NAME || 'webmail';
  if (!/^[A-Za-z0-9_]+$/.test(dbName)) {
    console.error('DB_NAME may only contain letters, numbers and underscores.');
    process.exit(1);
  }

  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });

  await conn.query(
    `CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
  );
  await conn.query(`USE \`${dbName}\``);
  await conn.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
  await conn.end();

  console.log(`Database "${dbName}" is ready (tables: users, messages).`);
})().catch((err) => {
  console.error('Could not set up the database:', err.message);
  console.error('Check DB_HOST / DB_USER / DB_PASSWORD in your .env file and that MySQL is running.');
  process.exit(1);
});

const db = require('../db');

const User = {
  async findByEmail(email) {
    const [rows] = await db.query('SELECT * FROM users WHERE email = ? LIMIT 1', [email]);
    return rows[0] || null;
  },

  async findById(id) {
    const [rows] = await db.query(
      'SELECT id, email, name, created_at FROM users WHERE id = ? LIMIT 1',
      [id]
    );
    return rows[0] || null;
  },

  async create({ email, passwordHash, name }) {
    const [result] = await db.query(
      'INSERT INTO users (email, password, name) VALUES (?, ?, ?)',
      [email, passwordHash, name]
    );
    return result.insertId;
  },

  async updateName(id, name) {
    await db.query('UPDATE users SET name = ? WHERE id = ?', [name, id]);
  },
};

module.exports = User;

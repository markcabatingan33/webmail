const db = require('../db');

const FOLDERS = ['inbox', 'sent', 'drafts', 'trash'];

// A message row is shared by two people, so "deleted" is tracked per side:
// 0 = kept, 1 = in Trash, 2 = deleted forever.
const FOLDER_WHERE = {
  inbox: 'm.receiver_id = ? AND m.receiver_deleted = 0 AND m.is_draft = 0',
  sent: 'm.sender_id = ? AND m.sender_deleted = 0 AND m.is_draft = 0',
  drafts: 'm.sender_id = ? AND m.sender_deleted = 0 AND m.is_draft = 1',
  trash:
    '((m.receiver_id = ? AND m.receiver_deleted = 1 AND m.is_draft = 0) OR (m.sender_id = ? AND m.sender_deleted = 1))',
};

const PEOPLE_JOIN = `
  FROM messages m
  JOIN users s ON s.id = m.sender_id
  LEFT JOIN users r ON r.id = m.receiver_id`;

const PEOPLE_COLUMNS = `
  m.id, m.subject, m.sent_at, m.is_read, m.is_draft, m.draft_to, m.sender_id, m.receiver_id,
  s.name AS sender_name, s.email AS sender_email,
  r.name AS receiver_name, r.email AS receiver_email`;

const escapeLike = (text) => text.replace(/[\\%_]/g, '\\$&');

const Message = {
  FOLDERS,

  async listByFolder(userId, folder, search = '') {
    const params = folder === 'trash' ? [userId, userId] : [userId];
    let where = FOLDER_WHERE[folder];

    if (search) {
      const like = `%${escapeLike(search)}%`;
      where += ` AND (m.subject LIKE ? OR m.body LIKE ? OR s.name LIKE ? OR s.email LIKE ?
                      OR r.name LIKE ? OR r.email LIKE ? OR m.draft_to LIKE ?)`;
      params.push(like, like, like, like, like, like, like);
    }

    const [rows] = await db.query(
      `SELECT ${PEOPLE_COLUMNS}, LEFT(m.body, 140) AS preview
       ${PEOPLE_JOIN}
       WHERE ${where}
       ORDER BY m.sent_at DESC, m.id DESC
       LIMIT 200`,
      params
    );
    return rows;
  },

  // Returns the message only if this user is the sender or the receiver (and hasn't deleted it forever).
  async findForUser(id, userId) {
    const [rows] = await db.query(
      `SELECT ${PEOPLE_COLUMNS}, m.body
       ${PEOPLE_JOIN}
       WHERE m.id = ?
         AND ((m.sender_id = ? AND m.sender_deleted < 2)
           OR (m.receiver_id = ? AND m.receiver_deleted < 2 AND m.is_draft = 0))
       LIMIT 1`,
      [id, userId, userId]
    );
    return rows[0] || null;
  },

  async counts(userId) {
    const [rows] = await db.query(
      `SELECT
         (SELECT COUNT(*) FROM messages
           WHERE receiver_id = ? AND receiver_deleted = 0 AND is_draft = 0 AND is_read = 0) AS unread,
         (SELECT COUNT(*) FROM messages
           WHERE sender_id = ? AND sender_deleted = 0 AND is_draft = 1) AS drafts`,
      [userId, userId]
    );
    return { unread: Number(rows[0].unread), drafts: Number(rows[0].drafts) };
  },

  async create({ senderId, receiverId, subject, body }) {
    const [result] = await db.query(
      'INSERT INTO messages (sender_id, receiver_id, subject, body) VALUES (?, ?, ?, ?)',
      [senderId, receiverId, subject, body]
    );
    return result.insertId;
  },

  // Creates a draft, or updates an existing one when `id` is given. Returns the draft id (or null).
  async saveDraft({ id, senderId, to, subject, body }) {
    if (id) {
      const [result] = await db.query(
        `UPDATE messages SET draft_to = ?, subject = ?, body = ?, sent_at = CURRENT_TIMESTAMP
         WHERE id = ? AND sender_id = ? AND is_draft = 1 AND sender_deleted < 2`,
        [to, subject, body, id, senderId]
      );
      return result.affectedRows ? id : null;
    }
    const [result] = await db.query(
      'INSERT INTO messages (sender_id, receiver_id, is_draft, draft_to, subject, body) VALUES (?, NULL, 1, ?, ?, ?)',
      [senderId, to, subject, body]
    );
    return result.insertId;
  },

  // Turns a saved draft into a real sent message.
  async sendDraft({ id, senderId, receiverId, subject, body }) {
    const [result] = await db.query(
      `UPDATE messages
       SET receiver_id = ?, draft_to = NULL, subject = ?, body = ?, is_draft = 0,
           is_read = 0, sender_deleted = 0, receiver_deleted = 0, sent_at = CURRENT_TIMESTAMP
       WHERE id = ? AND sender_id = ? AND is_draft = 1 AND sender_deleted < 2`,
      [receiverId, subject, body, id, senderId]
    );
    return result.affectedRows > 0;
  },

  async markRead(id, userId) {
    await db.query('UPDATE messages SET is_read = 1 WHERE id = ? AND receiver_id = ?', [id, userId]);
  },

  async moveToTrash(id, userId) {
    const [result] = await db.query(
      `UPDATE messages SET
         sender_deleted   = IF(sender_id = ? AND sender_deleted = 0, 1, sender_deleted),
         receiver_deleted = IF(receiver_id = ? AND receiver_deleted = 0 AND is_draft = 0, 1, receiver_deleted)
       WHERE id = ? AND (sender_id = ? OR receiver_id = ?)`,
      [userId, userId, id, userId, userId]
    );
    return result.affectedRows > 0;
  },

  // True if this message is currently in the user's Trash.
  async isInTrash(id, userId) {
    const [rows] = await db.query(
      `SELECT id FROM messages
       WHERE id = ? AND ((sender_id = ? AND sender_deleted = 1)
                      OR (receiver_id = ? AND receiver_deleted = 1 AND is_draft = 0))
       LIMIT 1`,
      [id, userId, userId]
    );
    return rows.length > 0;
  },

  async restore(id, userId) {
    if (!(await Message.isInTrash(id, userId))) return false;
    const [result] = await db.query(
      `UPDATE messages SET
         sender_deleted   = IF(sender_id = ? AND sender_deleted = 1, 0, sender_deleted),
         receiver_deleted = IF(receiver_id = ? AND receiver_deleted = 1, 0, receiver_deleted)
       WHERE id = ? AND (sender_id = ? OR receiver_id = ?)`,
      [userId, userId, id, userId, userId]
    );
    return result.affectedRows > 0;
  },

  // "Delete forever" only works on messages already in Trash. The row itself is removed
  // once nobody can see it anymore.
  async deleteForever(id, userId) {
    if (!(await Message.isInTrash(id, userId))) return false;
    const [result] = await db.query(
      `UPDATE messages SET
         sender_deleted   = IF(sender_id = ? AND sender_deleted = 1, 2, sender_deleted),
         receiver_deleted = IF(receiver_id = ? AND receiver_deleted = 1, 2, receiver_deleted)
       WHERE id = ? AND (sender_id = ? OR receiver_id = ?)`,
      [userId, userId, id, userId, userId]
    );
    await db.query(
      `DELETE FROM messages
       WHERE id = ? AND sender_deleted = 2 AND (receiver_id IS NULL OR receiver_deleted = 2)`,
      [id]
    );
    return result.affectedRows > 0;
  },
};

module.exports = Message;

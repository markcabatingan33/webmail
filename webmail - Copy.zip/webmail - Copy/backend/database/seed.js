// Adds a demo account and a few sample emails.  Usage: npm run seed
const bcrypt = require('bcryptjs');
const db = require('./db');
const User = require('./models/User');

const DEMO_PASSWORD = 'password123';

(async () => {
  const existing = await User.findByEmail('demo@mywebmail.com');
  if (existing) {
    console.log('Demo data already exists. Log in with demo@mywebmail.com / ' + DEMO_PASSWORD);
    return;
  }

  const hash = await bcrypt.hash(DEMO_PASSWORD, 10);
  const people = {
    demo: ['demo@mywebmail.com', 'Demo User'],
    john: ['john@mywebmail.com', 'John Doe'],
    maria: ['maria@mywebmail.com', 'Maria Santos'],
    alex: ['alex@mywebmail.com', 'Alex Rivera'],
    support: ['support@mywebmail.com', 'Support Team'],
    admin: ['admin@mywebmail.com', 'Admin'],
  };
  const id = {};
  for (const [key, [email, name]] of Object.entries(people)) {
    id[key] = await User.create({ email, name, passwordHash: hash });
  }

  const minutesAgo = (m) => new Date(Date.now() - m * 60 * 1000);
  const messages = [
    // [from, to, subject, body, sentAt, isRead]
    ['john', 'demo', 'Project Meeting', 'Hi!\n\nCan we move our project meeting to 10:30 tomorrow? I want to go over the storyboard together.\n\nThanks,\nJohn', minutesAgo(20), 0],
    ['maria', 'demo', 'Assignment', 'Hello,\n\nI uploaded the assignment draft. Please review it when you have time and tell me what to fix.\n\n- Maria', minutesAgo(90), 0],
    ['alex', 'demo', 'Hello!', 'Hey, just checking in. How is the webmail project going?', minutesAgo(60 * 22), 0],
    ['support', 'demo', 'Welcome to MyWebMail', 'Welcome aboard!\n\nYour inbox is ready. Use Compose to write a new message, and Trash to restore anything you delete by mistake.\n\n- The MyWebMail Team', minutesAgo(60 * 26), 0],
    ['admin', 'demo', 'System Update', 'We will run a short maintenance on Sunday at 2:00 AM. No action is needed on your side.', minutesAgo(60 * 24 * 30), 1],
    ['demo', 'maria', 'Assignment', 'Hi Maria, I finished my part. Please check the shared folder.', minutesAgo(60 * 24 * 3), 1],
    ['demo', 'john', 'Project Update', 'Hi John, the login and inbox pages are done. Compose is next.', minutesAgo(60 * 24 * 4), 1],
    ['demo', 'alex', 'Re: Hello!', 'All good here! Thanks for asking.', minutesAgo(60 * 24 * 5), 1],
  ];
  for (const [from, to, subject, body, sentAt, isRead] of messages) {
    await db.query(
      'INSERT INTO messages (sender_id, receiver_id, subject, body, sent_at, is_read) VALUES (?, ?, ?, ?, ?, ?)',
      [id[from], id[to], subject, body, sentAt, isRead]
    );
  }

  console.log('Demo data added.');
  console.log('Log in with:  demo@mywebmail.com  /  ' + DEMO_PASSWORD);
  console.log('Other accounts (same password): john@, maria@, alex@, support@, admin@ mywebmail.com');
})()
  .catch((err) => {
    console.error('Seeding failed:', err.message);
    process.exitCode = 1;
  })
  .finally(() => db.end());

-- MyWebMail database structure (MySQL / MariaDB)
-- Run with:  npm run init-db

CREATE TABLE IF NOT EXISTS users (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  email       VARCHAR(255) NOT NULL,
  password    VARCHAR(255) NOT NULL,           -- bcrypt hash, never plain text
  name        VARCHAR(100) NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS messages (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sender_id         INT UNSIGNED NOT NULL,
  receiver_id       INT UNSIGNED NULL,          -- NULL while it is still a draft
  subject           VARCHAR(255) NOT NULL DEFAULT '',
  body              TEXT         NOT NULL,
  sent_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_read           TINYINT(1)   NOT NULL DEFAULT 0,
  is_draft          TINYINT(1)   NOT NULL DEFAULT 0,
  draft_to          VARCHAR(255) NULL,          -- recipient typed into a draft
  sender_deleted    TINYINT(1)   NOT NULL DEFAULT 0,  -- 0 = kept, 1 = in Trash, 2 = deleted forever
  receiver_deleted  TINYINT(1)   NOT NULL DEFAULT 0,  -- same values, from the receiver's side
  PRIMARY KEY (id),
  KEY idx_inbox  (receiver_id, receiver_deleted, is_draft, sent_at),
  KEY idx_sent   (sender_id, sender_deleted, is_draft, sent_at),
  CONSTRAINT fk_messages_sender   FOREIGN KEY (sender_id)   REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_messages_receiver FOREIGN KEY (receiver_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

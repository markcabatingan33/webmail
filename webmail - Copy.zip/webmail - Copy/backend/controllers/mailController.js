const Message = require('../database/models/Message');
const User = require('../database/models/User');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_SUBJECT = 255;
const MAX_BODY = 20000;

const wrap = (fn) => (req, res) =>
  fn(req, res).catch((err) => {
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again.' });
  });

const parseId = (value) => {
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
};

exports.list = wrap(async (req, res) => {
  const { folder } = req.params;
  if (!Message.FOLDERS.includes(folder)) {
    return res.status(400).json({ message: 'Unknown folder.' });
  }
  const search = String(req.query.q || '').trim().slice(0, 100);
  res.json(await Message.listByFolder(req.user.id, folder, search));
});

exports.counts = wrap(async (req, res) => {
  res.json(await Message.counts(req.user.id));
});

exports.get = wrap(async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ message: 'Invalid message id.' });

  const message = await Message.findForUser(id, req.user.id);
  if (!message) return res.status(404).json({ message: 'Message not found.' });

  // Opening a received message marks it as read.
  if (message.receiver_id === req.user.id && !message.is_draft && !message.is_read) {
    await Message.markRead(id, req.user.id);
    message.is_read = 1;
  }
  res.json(message);
});

exports.send = wrap(async (req, res) => {
  const to = String(req.body.to || '').trim().toLowerCase();
  const subject = String(req.body.subject || '').trim() || '(no subject)';
  const body = String(req.body.body || '').trim();
  const draftId = req.body.draftId ? parseId(req.body.draftId) : null;

  if (!EMAIL_RE.test(to)) return res.status(400).json({ message: 'Enter a valid recipient email.' });
  if (subject.length > MAX_SUBJECT) {
    return res.status(400).json({ message: `Subject is too long (${MAX_SUBJECT} characters max).` });
  }
  if (!body) return res.status(400).json({ message: 'Write a message before sending.' });
  if (body.length > MAX_BODY) {
    return res.status(400).json({ message: `Message is too long (${MAX_BODY} characters max).` });
  }

  const recipient = await User.findByEmail(to);
  if (!recipient) {
    return res.status(404).json({ message: `No MyWebMail account exists for ${to}.` });
  }

  let id;
  if (draftId) {
    const sent = await Message.sendDraft({
      id: draftId, senderId: req.user.id, receiverId: recipient.id, subject, body,
    });
    if (!sent) return res.status(404).json({ message: 'That draft no longer exists.' });
    id = draftId;
  } else {
    id = await Message.create({
      senderId: req.user.id, receiverId: recipient.id, subject, body,
    });
  }
  res.status(201).json({ id, message: 'Message sent.' });
});

exports.saveDraft = wrap(async (req, res) => {
  const to = String(req.body.to || '').trim().slice(0, 255);
  const subject = String(req.body.subject || '').trim().slice(0, MAX_SUBJECT);
  const body = String(req.body.body || '').slice(0, MAX_BODY);
  const draftId = req.body.draftId ? parseId(req.body.draftId) : null;

  if (!to && !subject && !body.trim()) {
    return res.status(400).json({ message: 'Nothing to save yet.' });
  }

  const id = await Message.saveDraft({
    id: draftId, senderId: req.user.id, to: to || null, subject, body,
  });
  if (!id) return res.status(404).json({ message: 'That draft no longer exists.' });
  res.json({ id, message: 'Draft saved.' });
});

exports.remove = wrap(async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ message: 'Invalid message id.' });

  const forever = req.query.permanent === 'true';
  const done = forever
    ? await Message.deleteForever(id, req.user.id)
    : await Message.moveToTrash(id, req.user.id);
  if (!done) {
    return res.status(404).json({
      message: forever ? 'Only messages in Trash can be deleted forever.' : 'Message not found.',
    });
  }
  res.json({ message: forever ? 'Deleted forever.' : 'Moved to Trash.' });
});

exports.restore = wrap(async (req, res) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ message: 'Invalid message id.' });

  const done = await Message.restore(id, req.user.id);
  if (!done) return res.status(404).json({ message: 'That message is not in Trash.' });
  res.json({ message: 'Restored.' });
});

const bcrypt = require('bcryptjs');
const User = require('../database/models/User');
const { signToken } = require('../middleware/auth');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email });

const wrap = (fn) => (req, res) =>
  fn(req, res).catch((err) => {
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again.' });
  });

exports.register = wrap(async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  if (!name) return res.status(400).json({ message: 'Enter your name.' });
  if (name.length > 100) return res.status(400).json({ message: 'Name is too long (100 characters max).' });
  if (!EMAIL_RE.test(email) || email.length > 255) {
    return res.status(400).json({ message: 'Enter a valid email address.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ message: 'Password must be at least 6 characters.' });
  }
  if (await User.findByEmail(email)) {
    return res.status(409).json({ message: 'That email is already registered. Try logging in.' });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const id = await User.create({ email, name, passwordHash });
  const user = { id, name, email };
  res.status(201).json({ token: signToken(user), user });
});

exports.login = wrap(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!email || !password) {
    return res.status(400).json({ message: 'Enter your email and password.' });
  }

  const user = await User.findByEmail(email);
  const ok = user && (await bcrypt.compare(password, user.password));
  if (!ok) return res.status(401).json({ message: 'Wrong email or password.' });

  res.json({ token: signToken(user), user: publicUser(user) });
});

exports.me = wrap(async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user) return res.status(401).json({ message: 'Account not found. Please log in again.' });
  res.json(publicUser(user));
});

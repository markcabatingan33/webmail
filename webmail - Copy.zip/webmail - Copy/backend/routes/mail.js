const router = require('express').Router();
const mail = require('../controllers/mailController');
const { authRequired } = require('../middleware/auth');

router.use(authRequired);

router.get('/counts', mail.counts);
router.get('/folder/:folder', mail.list);   // inbox | sent | drafts | trash  (?q=search)
router.post('/send', mail.send);
router.post('/draft', mail.saveDraft);
router.get('/:id', mail.get);
router.post('/:id/restore', mail.restore);
router.delete('/:id', mail.remove);         // ?permanent=true to delete forever (Trash only)

module.exports = router;

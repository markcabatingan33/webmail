const router = require('express').Router();
const User = require('../database/models/User');
const { authRequired } = require('../middleware/auth');

router.use(authRequired);

router.get('/profile', async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: 'Account not found.' });
    res.json(user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

router.put('/profile', async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    if (!name || name.length > 100) {
      return res.status(400).json({ message: 'Enter a name (100 characters max).' });
    }
    await User.updateName(req.user.id, name);
    res.json(await User.findById(req.user.id));
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error. Please try again.' });
  }
});

module.exports = router;

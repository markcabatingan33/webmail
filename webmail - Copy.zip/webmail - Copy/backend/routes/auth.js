const router = require('express').Router();
const auth = require('../controllers/authController');
const { authRequired } = require('../middleware/auth');

router.post('/register', auth.register);
router.post('/login', auth.login);
router.get('/me', authRequired, auth.me);

module.exports = router;

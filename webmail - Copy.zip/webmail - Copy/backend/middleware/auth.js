const jwt = require('jsonwebtoken');

const secret = () => process.env.JWT_SECRET || 'dev-only-secret-change-me';

function signToken(user) {
  return jwt.sign({ id: user.id }, secret(), { expiresIn: '7d' });
}

// Protects a route: requires "Authorization: Bearer <token>" and sets req.user = { id }.
function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Please log in first.' });

  try {
    const payload = jwt.verify(token, secret());
    req.user = { id: payload.id };
    next();
  } catch (err) {
    res.status(401).json({ message: 'Your session has expired. Please log in again.' });
  }
}

module.exports = { signToken, authRequired };
